function showCalculator(id) {
    document.querySelectorAll('.calc-section').forEach(sec => sec.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
}

function calculateAge() {
    const dob = new Date(document.getElementById('dob').value);
    const refDateInput = document.getElementById('refDate').value;
    const refDate = refDateInput ? new Date(refDateInput) : new Date();

    if (!dob || isNaN(dob)) {
        document.getElementById('ageResult').innerHTML = "<p>Please enter a valid Date of Birth.</p>";
        return;
    }

    let years = refDate.getFullYear() - dob.getFullYear();
    let months = refDate.getMonth() - dob.getMonth();
    let days = refDate.getDate() - dob.getDate();

    if (days < 0) {
        months--;
        const prevMonth = new Date(refDate.getFullYear(), refDate.getMonth(), 0);
        days += prevMonth.getDate();
    }
    if (months < 0) {
        years--;
        months += 12;
    }

    const diffMs = refDate - dob;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHours = Math.floor(diffMin / 60);
    const diffDays = Math.floor(diffHours / 24);
    const diffWeeks = Math.floor(diffDays / 7);

    document.getElementById('ageResult').innerHTML = `
        <p><strong>Age:</strong> ${years} years, ${months} months, ${days} days</p>
        <p>or ${years * 12 + months} months, ${days} days</p>
        <p>or ${diffWeeks} weeks, ${diffDays % 7} days</p>
        <p>or ${diffDays} days</p>
        <p>or ${diffHours} hours</p>
        <p>or ${diffMin} minutes</p>
        <p>or ${diffSec} seconds</p>
    `;
}
