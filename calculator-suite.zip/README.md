# Calculator Suite

This is a free, all-in-one calculator website including:
- Age Calculator (fully functional)
- Placeholders for Mortgage, Loan, BMI, and more calculators

## Deployment on GitHub Pages
1. Go to [github.com](https://github.com) and create a new repository (public).
2. Upload these files: `index.html`, `style.css`, `script.js`.
3. Commit changes.
4. Go to **Settings > Pages**.
5. Under "Source", select **main branch** and save.
6. Your site will be live at `https://yourusername.github.io/repositoryname`.

---
© 2025 Calculator Suite
